ULTIMATE ME — Quest System V3

Includes:
- Daily missions and weekly Boss Quests
- Aura rewards, XP, levels 1–100, titles, attributes, achievements and journey milestones
- Offline-first localStorage progress
- Service worker for offline caching
- Custom ULTIMATE ME app icon in 192px and 512px sizes
- PWA manifest configured for installation

IMPORTANT FOR ANDROID HOME SCREEN:
The old Chrome shortcut may keep its old icon. After installing the new version, remove the old shortcut and add/install ULTIMATE ME again.

For a true standalone PWA installation, serve this folder from HTTPS (or localhost). A plain LAN HTTP address such as http://10.x.x.x:8080 may only allow a browser shortcut and may not allow Chrome to install the PWA.
